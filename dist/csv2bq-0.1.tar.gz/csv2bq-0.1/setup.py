from setuptools import setup
setup(
    name="csv2bq",
    version="0.1",
    author="Hiroyuki Kuromiya",
    packages=["csv2bq"],
)
